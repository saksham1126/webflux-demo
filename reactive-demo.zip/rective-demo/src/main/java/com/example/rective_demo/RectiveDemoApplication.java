package com.example.rective_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RectiveDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RectiveDemoApplication.class, args);
	}

}
